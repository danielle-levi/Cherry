// to get current year
function getYear() {
    var currentDate = new Date();
    var currentYear = currentDate.getFullYear();
    document.querySelector("#displayYear").innerHTML = currentYear;
}

getYear();

// overlay menu
function openNav() {
    document.getElementById("myNav").classList.toggle("menu_width");
    document.querySelector(".custom_menu-btn").classList.toggle("menu_btn-style");
}


/** google_map js **/

function myMap() {
    var mapProp = {
        center: new google.maps.LatLng(40.712775, -74.005973),
        zoom: 18,
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
}

// lightbox gallery
$(document).on("click", '[data-toggle="lightbox"]', function (event) {
    event.preventDefault();
    $(this).ekkoLightbox();
});

// read more- מקצרת טקסטים ארוכים ומוסיפה כפתור לקריאה מלאה

document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".detail-box").forEach(function (box) {
        let text = box.querySelector(".blog-text");
        let button = document.createElement("button");
        button.classList.add("read-more-btn");
        button.innerText = "Read More";
        
        if (text.innerText.length > 15) {
            let shortText = text.innerText.substring(0, 15) + "...";
            let fullText = text.innerText;
            text.innerText = shortText;

            box.appendChild(button);

            button.addEventListener("click", function () {
                if (text.innerText === shortText) {
                    text.innerText = fullText;
                    button.innerText = "Read Less";
                } else {
                    text.innerText = shortText;
                    button.innerText = "Read More";
                }
            });
        }
    });
});
// Hamburger Menu Toggle for Mobile
document.addEventListener("DOMContentLoaded", function () {
    const menuCheckbox = document.getElementById("menu-toggle");
    const menu = document.querySelector(".menu");

    menuCheckbox.addEventListener("change", function () {
        if (this.checked) {
            menu.style.display = "flex";
        } else {
            menu.style.display = "none";
        }
    });
});

//The carousel should automatically transition
//between items without user interaction.
document.addEventListener("DOMContentLoaded", function () {
    let slider = document.querySelector(".shop_section .row");
    if (slider) {
        setInterval(() => {
            slider.scrollBy({ left: 250, behavior: "smooth" });
        }, 3000); // תזוזה כל 3 שניות
    }
});
document.addEventListener("DOMContentLoaded", function () {
    // Back to Top Button
    let backToTop = document.getElementById("back-to-top");

    window.addEventListener("scroll", function () {
        if (window.scrollY > window.innerHeight * 0.3) {
            backToTop.style.display = "block";
        } else {
            backToTop.style.display = "none";
        }
    });

    backToTop.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    // Countdown Timer
    function startCountdown(duration) {
        let timerElement = document.getElementById("timer");
        let endTime = Date.now() + duration * 1000;

        function updateTimer() {
            let timeLeft = endTime - Date.now();
            if (timeLeft > 0) {
                let hours = Math.floor(timeLeft / (1000 * 60 * 60));
                let minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                let seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
                timerElement.innerText = `${hours}h ${minutes}m ${seconds}s`;
            } else {
                timerElement.innerText = "Sale Ended!";
                clearInterval(timerInterval);
            }
        }

        updateTimer();
        let timerInterval = setInterval(updateTimer, 1000);
    }

    startCountdown(3600); // טיימר של שעה אחת (3600 שניות)
});
